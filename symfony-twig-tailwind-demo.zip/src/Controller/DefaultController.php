<?php
namespace App\Controller;

class DefaultController {
    public function index() {
        // placeholder for real controller logic
    }
}
